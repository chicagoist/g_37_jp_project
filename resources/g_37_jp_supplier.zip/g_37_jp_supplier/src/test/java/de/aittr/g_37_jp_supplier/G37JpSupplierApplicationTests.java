package de.aittr.g_37_jp_supplier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class G37JpSupplierApplicationTests {

	@Test
	void contextLoads() {
	}

}
