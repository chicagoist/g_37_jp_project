package de.aittr.g_37_jp_supplier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class G37JpSupplierApplication {

	public static void main(String[] args) {
		SpringApplication.run(G37JpSupplierApplication.class, args);
	}

}
